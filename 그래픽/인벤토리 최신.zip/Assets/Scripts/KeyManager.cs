﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyManager : MonoBehaviour {

	public Inventory inventory;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (inventory.gameObject.activeInHierarchy == false ) {
			if (Input.GetKeyDown(KeyCode.I)) {
				inventory.gameObject.SetActive (true);
			}			
		} 
		else {
			if (Input.GetKeyDown (KeyCode.I)) {
				inventory.gameObject.SetActive (false);
			}	
		}

	}
}
